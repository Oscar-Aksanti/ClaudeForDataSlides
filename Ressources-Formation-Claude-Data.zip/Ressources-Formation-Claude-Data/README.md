# Ressources — Maîtrisez l'Analyse des Données avec Claude

Tout ce qu'il faut pour animer les 5 jours de formation : prompts, cheatsheets, fichiers
d'exercice, templates, maquettes de dashboards, et les ressources externes vérifiées.

## Structure

```
01-Prompts/                  Tous les prompts des 5 jours — par jour (.md) et en un seul PDF
02-Cheatsheets/               8 fiches d'une page, imprimables, à distribuer ou projeter
03-Fichiers-Exercices/        Datasets synthétiques "sales", un dossier par jour
04-Templates/                 Documents vierges à remplir (capstone, plan 90 jours, portfolio)
05-Maquettes-Dashboards/      Maquettes cibles des 2 dashboards à construire (J1 et J2)
06-Ressources-Externes/       Liens vérifiés (Power BI, datasets SQL/R, prompts Claude)
```

## 01 — Prompts

Chaque prompt utilisé pendant les 5 jours, extrait directement du contenu de la plateforme —
rien n'a été réécrit, c'est exactement ce qui est projeté à l'écran. `Bibliotheque-Complete-Prompts.pdf`
regroupe tout ; les fichiers `Jour-N-Prompts.md` sont pratiques pour copier-coller pendant que tu prépares une session.

## 02 — Cheatsheets

Une page chacune, pensées pour être imprimées ou gardées ouvertes sur un second écran :
écosystème Claude, formules Excel, Power BI/DAX, jointures et fonctions fenêtre SQL, Git minimum,
protocole de vérification IA, sécurité/confidentialité, accessibilité des dashboards.

## 03 — Fichiers d'exercice

**Important : ce sont des données synthétiques, générées pour l'exercice — pas de vraies personnes,
pas une vraie organisation.** Elles reproduisent volontairement les pièges déjà décrits dans le
contenu (doublons, valeurs manquantes, formats incohérents, montants anormaux) pour que l'exercice
en direct retrouve exactement ce qui est montré à l'écran.

- **Jour 1** — `centre_sante_stock_brut.csv` : suivi de stock, à nettoyer dans Excel.
- **Jour 2** — `ong_transferts_monetaires_brut.csv` / `.xlsx` : programme de transferts monétaires, à nettoyer puis visualiser dans Power BI.
- **Jour 3** — `microfinance_prets.csv` : portefeuille de prêts, pour les requêtes SQL puis le pipeline Python.
- **Jour 4** — trois datasets au choix pour le projet capstone : distribution FMCG, coopérative cacao, résiliation mobile money.

## 04 — Templates

Documents vierges, à dupliquer pour chaque apprenant ou chaque projet :
brief de cadrage capstone, rapport décisionnel une page, plan d'action 90 jours (Excel avec
paliers 30/60/90), page de portfolio (Markdown).

## 05 — Maquettes de dashboards

**Ce sont des maquettes cibles, pas de vraies captures d'écran Power BI ou Excel** — lire le
README de ce dossier avant usage. Elles montrent la structure à viser, pas le rendu exact du
logiciel.

## 06 — Ressources externes

Liens vérifiés vers des ressources officielles et gratuites : échantillons Power BI Microsoft,
bases SQL d'exemple (Chinook, Sakila), jeux de données R/Python (Palmer Penguins), bibliothèque
de prompts et cookbook officiels Anthropic. Licence indiquée pour chacune — à revérifier sur la
page d'origine avant tout usage commercial ou redistribution.

---

*Généré pour Formations4data · Eurêka Services — formation "Maîtrisez l'Analyse des Données avec Claude", 13-17 juillet 2026.*
